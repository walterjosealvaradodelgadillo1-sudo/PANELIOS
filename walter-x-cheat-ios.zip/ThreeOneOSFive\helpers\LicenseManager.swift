import Combine
import Foundation
import Security
import UIKit

@MainActor
final class LicenseManager: ObservableObject {
    // MARK: - KeyAuth Configuration (API 1.3)
    private let keyAuthURL = URL(string: "https://keyauth.win/api/1.3/")!
    private let keyAuthName = "PANEL IOS"
    private let keyAuthOwnerID = "S12mtcUb8r"
    private let keyAuthVersion = "1.0"

    // MARK: - Published Properties
    @Published private(set) var expirationDate: Date?
    @Published private(set) var subscriptionName: String?
    @Published private(set) var username: String?
    @Published private(set) var isActive = false
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var contactOwner: String?
    @Published var rememberKey = true

    // MARK: - Keychain Keys
    private let service = "com.walterxcheat.ios.activation"
    private let keyAccount = "license-key"
    private let hwidAccount = "device-hwid"
    private var lastAttemptAt: Date?

    init() {
        // Validation occurs in beginLaunchSession()
    }

    var hasRememberedKey: Bool {
        !(string(for: keyAccount) ?? "").isEmpty
    }

    var hwid: String {
        if let existing = string(for: hwidAccount), existing.count >= 20 {
            return existing
        }
        let newHWID = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        save(newHWID, for: hwidAccount)
        return newHWID
    }

    func beginLaunchSession() {
        guard let savedKey = rememberedKey(), !savedKey.isEmpty else {
            isActive = false
            message = nil
            return
        }

        // Auto-verify saved key with KeyAuth on app launch
        verify(key: savedKey, isAutomatic: true)
    }

    func activate(key: String) {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isBusy else { return }

        if let lastAttemptAt, Date().timeIntervalSince(lastAttemptAt) < 1 {
            message = "Please wait a moment before trying again"
            return
        }
        lastAttemptAt = Date()

        verify(key: trimmed, isAutomatic: false)
    }

    private func verify(key: String, isAutomatic: Bool) {
        isBusy = true
        message = isAutomatic ? "Verifying license with KeyAuth…" : nil

        Task {
            do {
                let result = try await executeKeyAuthLogin(key: key)
                if result.success {
                    if self.rememberKey {
                        self.save(key, for: self.keyAccount)
                    }
                    self.expirationDate = result.expiry
                    self.subscriptionName = result.subName
                    self.username = result.username
                    self.isActive = true
                    self.message = nil
                } else {
                    if isAutomatic {
                        // Key expired or was reset in panel
                        self.delete(self.keyAccount)
                    }
                    self.isActive = false
                    self.message = result.message
                }
            } catch {
                self.isActive = false
                self.message = "Connection error: \(error.localizedDescription)"
            }
            self.isBusy = false
        }
    }

    func rememberedKey() -> String? {
        string(for: keyAccount)
    }

    func refresh() {
        if let key = rememberedKey(), !key.isEmpty {
            verify(key: key, isAutomatic: true)
        } else {
            isActive = false
            message = nil
        }
    }

    func deactivate() {
        delete(keyAccount)
        isActive = false
        expirationDate = nil
        subscriptionName = nil
        username = nil
        message = "Activation removed from this device"
    }

    // MARK: - KeyAuth API

    private struct KeyAuthResult {
        let success: Bool
        let message: String
        let expiry: Date?
        let subName: String?
        let username: String?
    }

    private func executeKeyAuthLogin(key: String) async throws -> KeyAuthResult {
        // Step 1: Init session (API 1.3 - no secret required)
        let initParams: [String: String] = [
            "type": "init",
            "name": keyAuthName,
            "ownerid": keyAuthOwnerID,
            "version": keyAuthVersion
        ]

        let initResponse = try await sendPostRequest(parameters: initParams)
        let initSuccess = initResponse["success"] as? Bool ?? false
        guard initSuccess, let sessionID = initResponse["sessionid"] as? String else {
            let msg = initResponse["message"] as? String ?? "Failed to initialize KeyAuth session"
            return KeyAuthResult(success: false, message: msg, expiry: nil, subName: nil, username: nil)
        }

        // Step 2: License login
        let currentHWID = hwid
        let licenseParams: [String: String] = [
            "type": "license",
            "key": key,
            "hwid": currentHWID,
            "sessionid": sessionID,
            "name": keyAuthName,
            "ownerid": keyAuthOwnerID
        ]

        let licenseResponse = try await sendPostRequest(parameters: licenseParams)
        let licSuccess = licenseResponse["success"] as? Bool ?? false
        let licMessage = licenseResponse["message"] as? String ?? (licSuccess ? "Activated successfully" : "License validation failed")

        var expiryDate: Date? = nil
        var subName: String? = nil
        var user: String? = nil

        if licSuccess, let info = licenseResponse["info"] as? [String: Any] {
            user = info["username"] as? String
            if let subscriptions = info["subscriptions"] as? [[String: Any]], let firstSub = subscriptions.first {
                subName = firstSub["subscription"] as? String
                if let expiryString = firstSub["expiry"] as? String, let timestamp = TimeInterval(expiryString), timestamp > 0 {
                    expiryDate = Date(timeIntervalSince1970: timestamp)
                } else if let expiryNum = firstSub["expiry"] as? Double, expiryNum > 0 {
                    expiryDate = Date(timeIntervalSince1970: expiryNum)
                }
            }
        }

        return KeyAuthResult(
            success: licSuccess,
            message: licMessage,
            expiry: expiryDate,
            subName: subName,
            username: user
        )
    }

    private func sendPostRequest(parameters: [String: String]) async throws -> [String: Any] {
        var request = URLRequest(url: keyAuthURL)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 15

        let bodyString = parameters.map { key, value in
            let escapedKey = urlEncode(key)
            let escapedVal = urlEncode(value)
            return "\(escapedKey)=\(escapedVal)"
        }.joined(separator: "&")

        request.httpBody = bodyString.data(using: .utf8)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw NSError(domain: "KeyAuth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Server returned error"])
        }

        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw NSError(domain: "KeyAuth", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid server response"])
        }

        return json
    }

    private func urlEncode(_ string: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return string.addingPercentEncoding(withAllowedCharacters: allowed) ?? string
    }

    // MARK: - Keychain Helpers

    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
